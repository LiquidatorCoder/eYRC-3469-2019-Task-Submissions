/*
*
* Team Id: 3469
* Author List: Abhay Maurya, Ratnesh Mohan, Shubhankar Jain, Saumya Gupta
* Filename: CB_Task_1_Sandbox.cpp
* Theme: Construct-O-Bot - Specific to eYRC
* Functions: forward_wls,forward_inv,left_turn_wls,right_turn_wls,print,dijkstra,static_reorientation,proximity_analysis,forward_walls,
* fplace,forward_untw,left_turn_wwls,right_turn_wwls,forward_wls_house,forward_zigzag_1021,forward_zigzag_2110,left_turn_inv_wls,right_turn_inv_wls,
* forward_inv_1516,forward_inv_1617,forward_inv_1716,forward_inv_1615,traverse,dist_comp,e_shape,Task_1_1,Task_1_2
* Global Variables: for_vel,left_vel,right_vel,sleft_vel,sright_vel,n,u,face,fdir,h1,h2,h3,h4,h5,G,dis,pre,movement_array
*
*/
//You are allowed to define your own function to fulfill the requirement of tasks
//Dont change the name of following functions

#include "CB_Task_1_Sandbox.h"

#define inf 0							//defining inf as 0 and infi as 9999
#define infi 9999
#include <algorithm>					//including algorithm and vector header files
#include <vector> 
#include<iostream>						//including iostream header file for console logging
using namespace std;					//using standard namespace

//global velocity variables
int for_vel = 255;
int left_vel = 80;
int right_vel = 80;
int sleft_vel = 60;
int sright_vel = 60;

//total node count and initial node
int n = 32;
int u = 0;

//direction variables which include directions w,n,e,s
char face = 'w';
char fdir = 'n';

//house variables which include node number of houses
int h1 = 6;
int h2 = 27;
int h3 = 11;
int h4 = 22;
int h5 = 16;

//undirected adjacency matrix for the given graph configuration
int G[32][32] = {
	//	  0   1	  2	  3	  4	  5	  6	  7	  8	  9	 10	 11	 12	 13	 14	 15	 16	 17	 18	 19	 20	 21	 22	 23	 24	 25	 26	 27	 28	 29	 30	 31
		{inf,5,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,5},//0
		{5,inf,3,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf},//1
		{inf,3,inf,1,1,3,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf},//2
		{inf,inf,1,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf},//3
		{inf,inf,1,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf},//4
		{inf,inf,3,inf,inf,inf,1,3,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,12,inf,inf,inf,inf,inf},//5
		{inf,inf,inf,inf,inf,1,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf},//6
		{inf,inf,inf,inf,inf,3,inf,inf,1,1,3,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf},//7
		{inf,inf,inf,inf,inf,inf,inf,1,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf},//8
		{inf,inf,inf,inf,inf,inf,inf,1,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf},//9
		{inf,inf,inf,inf,inf,inf,inf,3,inf,inf,inf,1,3,inf,inf,inf,inf,inf,inf,inf,inf,15,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf},//10
		{inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,1,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf},//11
		{inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,3,inf,inf,1,1,3,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf},//12
		{inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,1,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf},//13
		{inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,1,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf},//14
		{inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,3,inf,inf,inf,10,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf},//15
		{inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,10,inf,10,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf},//16
		{inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,10,inf,3,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf},//17
		{inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,3,inf,1,1,3,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf},//18
		{inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,1,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf},//19
		{inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,1,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf},//20
		{inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,15,inf,inf,inf,inf,inf,inf,inf,3,inf,inf,inf,1,3,inf,inf,inf,inf,inf,inf,inf,inf},//21
		{inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,1,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf},//22
		{inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,3,inf,inf,1,1,3,inf,inf,inf,inf,inf},//23
		{inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,1,inf,inf,inf,inf,inf,inf,inf,inf},//24
		{inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,1,inf,inf,inf,inf,inf,inf,inf,inf},//25
		{inf,inf,inf,inf,inf,12,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,3,inf,inf,inf,1,3,inf,inf,inf},//26
		{inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,1,inf,inf,inf,inf,inf},//27
		{inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,3,inf,inf,1,1,3},//28
		{inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,1,inf,inf,inf},//29
		{inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,1,inf,inf,inf},//30
		{5,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,3,inf,inf,inf} };//31

//dis and pre arrays which stores distance between nodes and previous nodes for the current node
int dis[32];
int pre[32];

//movement array which stores node in n,e,s,w of the current node
int movement_array[32][4] = {
{inf,31,inf,2},
{2,0,inf,inf},
{5,4,1,3},
{inf,2,inf,inf},
{inf,inf,inf,2},
{7,26,2,6},
{inf,5,inf,inf},
{10,9,5,8},
{inf,7,inf,inf},
{inf,inf,inf,7},
{12,21,7,11},
{inf,10,inf,inf},
{15,14,10,13},
{inf,12,inf,inf},
{inf,inf,inf,12},
{inf,16,12,inf},
{inf,17,inf,15},
{inf,inf,18,16},
{17,19,21,20},
{inf,inf,inf,18},
{inf,18,inf,inf},
{18,22,23,10},
{inf,inf,inf,21},
{21,24,26,25},
{inf,inf,inf,23},
{inf,23,inf,inf},
{23,27,28,5},
{inf,inf,inf,26},
{26,29,31,30},
{inf,inf,inf,28},
{inf,28,inf,inf},
{28,inf,inf,0}
};

/*
*
* Function Name: print
* Input: vector array
* Output: void
* Logic: prints the given vector array on the comsole log
* Example Call: print(path); //prints vector array path on the console
*
*/
void print(std::vector<int> const& input)						//function used to print vector arrays onto console
{
	for (int i = 0; i < input.size(); i++) {
		std::cout << input.at(i) << ' ';
	}
}

/*
*
* Function Name: dijkstra
* Input: adjacency matrix, total nodes, initial node
* Output: void
* Logic: calculates the minimum distance between the initial node and every other node using weights stored in adjacency matrix
* Example Call: dijkstra(G, 32, 4); //calculates minimum distance between the 4th node and every other node based on the weights given in adjacency matrix
*
*/
void dijkstra(int G[32][32], int n, int startnode) {
	int cost[32][32], distance[32], pred[32];					//initialising cost, distance and perd arrays
	int visited[32], count, mindistance, nextnode, i, j;
	for (i = 0; i < n; i++)										//generating cost matrix
		for (j = 0; j < n; j++)
			if (G[i][j] == 0)
				cost[i][j] = infi;
			else
				cost[i][j] = G[i][j];
	for (i = 0; i < n; i++) {									//for loop to initialise visited array
		distance[i] = cost[startnode][i];
		pred[i] = startnode;
		visited[i] = 0;
	}
	distance[startnode] = 0;
	visited[startnode] = 1;
	count = 1;
	while (count < n - 1) {										//main while loop which calculates the distance using dijkstra algorithm
		mindistance = infi;
		for (i = 0; i < n; i++)
			if (distance[i] < mindistance && !visited[i]) {
				mindistance = distance[i];
				nextnode = i;
			}
		visited[nextnode] = 1;
		for (i = 0; i < n; i++)
			if (!visited[i])
				if (mindistance + cost[nextnode][i] < distance[i]) {
					distance[i] = mindistance + cost[nextnode][i];
					pred[i] = nextnode;
				}
		count++;
	}
	for (i = 0; i < n; i++)									//generating dis and pre arrays from distance and pred
	{
		dis[i] = distance[i];
	}
	for (i = 0; i < n; i++)
	{
		pre[i] = pred[i];
	}
	cout << "Dijkstra Completed!" << endl;
}

/*
*
* Function Name: static_reorientation
* Input: void
* Output: void
* Logic: reorients the robot to be along the black line
* Example Call: static_reorientation(); //reorients the robot to be along the black line
*
*/

void static_reorientation()
{
	stop();
	_delay_ms(300);
	unsigned char ls, ms, rs;							//initialising sensor variables
	int a = 0;
	int n = 0;
	do {												//main do while loop
		ls = ADC_Conversion(1);
		ms = ADC_Conversion(2);
		rs = ADC_Conversion(3);

		if (ls == 0 && ms == 0 && rs == 255)
		{
			right();
			velocity(right_vel, right_vel);
		}
		else if (ls == 255 && ms == 0 && rs == 0)
		{
			left();
			velocity(left_vel, left_vel);
		}
		else if (ls == 255 && ms == 255 && rs == 0)
		{
			soft_left();
			velocity(0, sleft_vel);
		}
		else if (ls == 0 && ms == 255 && rs == 255)
		{
			soft_right();
			velocity(sright_vel, 0);
		}
		else if (ls == 0 && ms == 0 && rs == 0)
		{
			back();
			_delay_ms(50);
		}
		else if (ls == 255 && ms == 255 && rs == 255)
		{
			forward();
		}
		if (ls == 0 && ms == 255 && rs == 0)
		{
			a = 1;											//Robot is now parallel to the black line.
		}
	} while (a == 0);

}

/*
*
* Function Name: static_reorientation_inv
* Input: void
* Output: void
* Logic: reorients the robot to be along the white line
* Example Call: static_reorientation_inv(); //reorients the robot to be along the white line
*

void static_reorientation_inv()
{
	stop();
	_delay_ms(300);
	unsigned char ls, ms, rs;								//initialising sensor variables
	int a = 0;
	int n = 0;
	do {													//main do while loop
		ls = ADC_Conversion(1);
		ms = ADC_Conversion(2);
		rs = ADC_Conversion(3);

		if (ls == 255 && ms == 255 && rs == 0)
		{
			right();
			velocity(right_vel, right_vel);
		}
		else if (ls == 0 && ms == 255 && rs == 255)
		{
			left();
			velocity(left_vel, left_vel);
		}
		else if (ls == 255 && ms == 255 && rs == 255)
		{
			back();
			_delay_ms(100);
		}
		if (ls == 255 && ms == 0 && rs == 255)
		{
			a = 1;									//Robot is now parallel to the white line.
		}
	} while (a == 0);

}

/*
*
* Function Name: proximity_analysis
* Input: void
* Output: void
* Logic: picks the box and updates the robots direction
* Example Call: proximity_analysis(); //picks the box and updates the robots direction
*
*/
void proximity_analysis()
{
	static_reorientation();									//correcting the robot position
	stop();
	_delay_ms(100);
	pick();													//picking the box
	right_turn_wls();
	if (face == 'n')										//correcting robot direction
	{
		face == 's';
		cout << "Current Direction " << face << endl;
	}
	else if (face == 'e')
	{
		face == 'w';
		cout << "Current Direction " << face << endl;
	}
	else if (face == 's')
	{
		face == 'n';
		cout << "Current Direction " << face << endl;
	}
	else if (face == 'w')
	{
		face == 'e';
		cout << "Current Direction " << face << endl;
	}
}

/*
*
* Function Name:  forward_walls
* Input: void
* Output: void
* Logic: helps the robot in traversing through wall following situation
* Example Call:  forward_walls(); //helps the robot in traversing through wall following situation
*
*/
void forward_walls()
{
	unsigned char ls, ms, rs, lps, mps, rps;
	int n = 0;
	while (1)
	{
		_delay_ms(5);											//checking sensor values
		ls = ADC_Conversion(1);
		ms = ADC_Conversion(2);
		rs = ADC_Conversion(3);
		lps = ADC_Conversion(5);
		mps = ADC_Conversion(4);
		rps = ADC_Conversion(6);
		if (ls == 255 && ms == 255 && rs == 255)				//node counter
		{
			n++;
		}
		if (n < 1)												//line following alogorithm
		{
			if (ls == 0 && ms == 255 && rs == 0)
			{
				forward();
				velocity(for_vel, for_vel);
			}
			else if (ls == 0 && ms == 0 && rs == 255)
			{
				right();
				velocity(60, 60);
			}
			else if (ls == 255 && ms == 0 && rs == 0)
			{
				left();
				velocity(60, 60);
			}
			else if (ls == 255 && ms == 255 && rs == 255)
			{
				forward();
				velocity(255, for_vel);
			}
			else if (ls == 0 && ms == 0 && rs == 0)						//if line is not found
			{
				if (lps != 32 || rps != 32)								//wall following algorithm
				{
					if (lps > rps&& lps >= 110)
					{
						cout << "\nLeft!";
						left();
						velocity(38, 39);
						_delay_ms(1);
					}
					else if (lps < rps && rps >= 105)
					{
						cout << "\nRight!";
						right();
						velocity(39, 37);
						_delay_ms(1);
					}
					else if (lps > rps&& rps == 32 && lps >= 105)
					{
						cout << "\nRight!";
						right();
						velocity(39, 37);
						_delay_ms(1);
					}
					else if (lps < rps && lps == 32 && rps >= 100)
					{
						cout << "\nLeft!";
						left();
						velocity(28, 29);
						_delay_ms(1);
					}
					else if (lps > rps&& rps > 125)
					{
						cout << "\nLeft!";
						left();
						_delay_ms(1);
						velocity(29, 34);
						_delay_ms(1);
					}
					else if (lps < rps && lps > 120)
					{
						cout << "\nRight!";
						right();
						_delay_ms(1);
						velocity(44, 49);
						_delay_ms(1);
					}
				}
				forward();
				velocity(220, 220);
			}
		}
		else
		{
			stop();
			break;
		}
	}														//if node is detected place the robot on the node
	forward();
	velocity(255, 255);
	_delay_ms(300);
}

/*
*
* Function Name: fplace
* Input: void
* Output: void
* Logic: places the box and updates the robots direction
* Example Call: fplace(); //places the box and updates the robots direction
*
*/
void fplace()
{
	unsigned char pf;
	static_reorientation();
	forward();
	_delay_ms(50);
	left();
	_delay_ms(60);
	stop();
	_delay_ms(200);
	pf = ADC_Conversion(4);
	printf("\n %d", pf);
	if (pf != 32)						//if another block is placed
	{
		back();
		_delay_ms(50);
		right();
		_delay_ms(100);
		stop();
		_delay_ms(200);
		place();						//placing the box
	}
	if (pf == 32)						//if no block is placed
	{
		place();
		back();
		_delay_ms(50);
	}
}
/*
*
* Function Name: iplace
* Input: void
* Output: void
* Logic: places the box and updates the robots direction in inverse area
* Example Call: iplace(); //places the box and updates the robots direction in inverse area
*
*/
void iplace()
{
	unsigned char pf;
	forward();
	_delay_ms(50);
	left();
	_delay_ms(70);
	stop();
	_delay_ms(200);
	pf = ADC_Conversion(4);
	printf("\n %d", pf);
	if (pf != 32)						//if another block is placed
	{
		back();
		_delay_ms(50);
		right();
		_delay_ms(110);
		stop();
		_delay_ms(200);
		place();
	}
	if (pf == 32)						//if no block is placed
	{
		place();
		back();
		_delay_ms(50);
	}
}

/*
*
* Function Name: left_turn_wwls
* Input: void
* Output: void
* Logic: Uses white line sensors to turn left until white line is encountered
* Example Call: left_turn_wls(); //Turns left until white line is encountered
*
*/
void left_turn_wwls(void)
{
	left();												//code which helps the robot to ignore the black line which is going straight so that it can focus on line which is going to the left
	_delay_ms(250);
	while (ADC_Conversion(2) == 255)					//while loop which detects black line using middle sensor so that the robot stops turning
	{
		left();
		velocity(127, 127);
		_delay_ms(2);
	}
}
/*
*
* Function Name: right_turn_wwls
* Input: void
* Output: void
* Logic: Uses white line sensors to turn right until white line is encountered
* Example Call: right_turn_wwls(); //Turns right until white line is encountered
*
*/
void right_turn_wwls(void)
{
	right();											//code which helps the robot to ignore the black line which is going straight so that it can focus on line which is going to the right
	_delay_ms(250);
	while (ADC_Conversion(2) == 255)					//while loop which detects black line using middle sensor so that the robot stops turning
	{
		right();
		velocity(127, 127);
		_delay_ms(2);
	}
}
/*
*
* Function Name: left_turn_inv_wls
* Input: void
* Output: void
* Logic: Uses white line sensors to turn left until white line is encountered
* Example Call: left_turn_inv_wls(); //Turns leftt until white line is encountered
*
*/
void left_turn_inv_wls(void)
{
	left();												//code which helps the robot to ignore the black line which is going straight so that it can focus on line which is going to the left
	_delay_ms(250);
	cout << endl << "inside left";
	while (ADC_Conversion(2) != 0)
	{
		left();
		velocity(127, 127);
		_delay_ms(2);
	}
}
/*
*
* Function Name: right_turn_inv_wls
* Input: void
* Output: void
* Logic: Uses white line sensors to turn right until white line is encountered
* Example Call: right_turn_inv_wls(); //Turns right until white line is encountered
*
*/
void right_turn_inv_wls(void)
{
	right();											//code which helps the robot to ignore the black line which is going straight so that it can focus on line which is going to the right
	_delay_ms(250);
	cout << endl << "inside right";

	while (ADC_Conversion(2) != 0)					//while loop which detects black line using middle sensor so that the robot stops turning
	{
		right();
		velocity(127, 127);
		_delay_ms(2);
	}
	cout << endl << ADC_Conversion(1) << " " << ADC_Conversion(2) << " " << ADC_Conversion(3);
}

/*
*
* Function Name: forward_untw
* Input: node,cnt
* Output: void
* Logic: Uses white line sensors to go forward by the number of nodes specified
* Example Call: forward_untw(1,40); //Goes forward by one node while threshold is 40
*
*/
void forward_untw(unsigned int node, int cnt)
{
	int n = 0;
	unsigned char ls, ms, rs;
	int c = 0;
	while (1)
	{
		ls = ADC_Conversion(1);				//sensor input
		ms = ADC_Conversion(2);
		rs = ADC_Conversion(3);

		if (ls == 0 && ms == 0 && rs == 0)
		{
			c++;
			_delay_ms(5);
			if (c > cnt)
			{

				c = 0;
				stop();
				break;
			}

		}
		if (n < node)						                         //checking if given node is reached
		{
			if (ls == 0 && ms == 255 && rs == 0)					// making choice of movement on the basis of sensor input
			{
				c = 0;                                              //main line following code which helps the robot to move forward along the black line
				forward();
				velocity(for_vel, for_vel);
			}
			else if (ls == 0 && ms == 0 && rs == 255)
			{
				right();
				velocity(right_vel, right_vel);
			}
			else if (ls == 255 && ms == 0 && rs == 0)
			{
				left();
				velocity(left_vel, left_vel);
			}
			else if (ls == 255 && ms == 255 && rs == 0)
			{
				soft_left();
				velocity(0, sleft_vel);
			}
			else if (ls == 0 && ms == 255 && rs == 255)
			{
				soft_right();
				velocity(sright_vel, 0);
			}
			else if (ls == 255 && ms == 0 && rs == 255)
			{
				forward();
				velocity(for_vel, for_vel);
			}
		}
		else													//if node reached then stop
		{
			stop();
			break;
		}
	}
}

/*
*
* Function Name: forward_wls
* Input: node
* Output: void
* Logic: Uses white line sensors to go forward by the number of nodes specified
* Example Call: forward_wls(2); //Goes forward by two nodes
*
*/
void forward_wls(unsigned char node)
{
	unsigned char ls, ms, rs;
	int n = 0;
	while (1)
	{


		ls = ADC_Conversion(1);				//sensor input
		ms = ADC_Conversion(2);
		rs = ADC_Conversion(3);




		if (ls == 255 && ms == 255 && rs == 255)
		{
			n++;
		}
		if (n < node)						                         //checking if given node is reached
		{
			if (ls == 0 && ms == 255 && rs == 0)					// making choice of movement on the basis of sensor input
			{														//main line following code which helps the robot to move forward along the black line
				forward();
				velocity(for_vel, for_vel);
			}
			else if (ls == 0 && ms == 0 && rs == 255)
			{
				right();
				velocity(right_vel, right_vel);
			}
			else if (ls == 255 && ms == 0 && rs == 0)
			{
				left();
				velocity(left_vel, left_vel);
			}
			else if (ls == 255 && ms == 255 && rs == 0)
			{
				soft_left();
				velocity(0, sleft_vel);
			}
			else if (ls == 0 && ms == 255 && rs == 255)
			{
				soft_right();
				velocity(sright_vel, 0);
			}
			else if (ls == 255 && ms == 0 && rs == 255)
			{
				forward();
				velocity(for_vel, for_vel);
			}
		}
		else													//if node reached then stop
		{
			stop();
			break;
		}
	}
	forward();													//code to move the robot tiny bit so that it is placed on the node
	velocity(255, 255);
	_delay_ms(300);
}

/*
*
* Function Name: forward_wls_house
* Input: node
* Output: void
* Logic: Uses white line sensors to go forward by the number of nodes specified near house
* Example Call: forward_wls(2); //Goes forward by two nodes
*
*/
void forward_wls_house(unsigned char node)
{
	unsigned char ls, ms, rs;
	int n = 0;

	while (1)
	{
		ls = ADC_Conversion(1);				//sensor input
		ms = ADC_Conversion(2);
		rs = ADC_Conversion(3);
		if (ls == 255 && ms == 255 && rs == 255)
		{
			n++;
		}
		if (n < node)						                         //checking if given node is reached
		{
			if (ls == 0 && ms == 255 && rs == 0)					// making choice of movement on the basis of sensor input
			{														//main line following code which helps the robot to move forward along the black line
				forward();
				velocity(for_vel, for_vel);
			}
			else if (ls == 0 && ms == 0 && rs == 255)
			{
				right();
				velocity(right_vel, right_vel);
			}
			else if (ls == 255 && ms == 0 && rs == 0)
			{
				left();
				velocity(left_vel, left_vel);
			}
			else if (ls == 255 && ms == 255 && rs == 0)
			{
				soft_left();
				velocity(0, sleft_vel);
			}
			else if (ls == 0 && ms == 255 && rs == 255)
			{
				soft_right();
				velocity(sright_vel, 0);
			}
			else if (ls == 255 && ms == 0 && rs == 255)
			{
				forward();
				velocity(for_vel, for_vel);
			}
		}
		else													//if node reached then stop
		{
			stop();
			break;
		}
	}
	forward();													//code to move the robot tiny bit so that it is placed on the node
	velocity(255, 255);
	_delay_ms(100);
}

/*
*
* Function Name: forward_zigzag_1021
* Input: node
* Output: void
* Logic: Uses white line sensors to go forward on zigzag lines by the number of nodes specified from nodes 10 to 21
* Example Call: forward_zigzag_1021(1); //Goes forward by one node on zigzag from nodes 10 to 21
*
*/

void forward_zigzag_1021(unsigned char node)
{
	int c = 40;
	forward_untw(1, 55);
	stop();
	_delay_ms(40);

	while (ADC_Conversion(2) != 255)					//while loop which detects black line using middle sensor so that the robot stops turning
	{
		left();
		velocity(80, 81);
		_delay_ms(2);
	}

	stop();
	_delay_ms(50);
	forward_untw(1, c);
	while (ADC_Conversion(2) != 255)					//while loop which detects black line using middle sensor so that the robot stops turning
	{
		right();
		velocity(81, 80);
		_delay_ms(2);
	}

	stop();
	_delay_ms(50);
	forward_untw(1, c);
	stop();
	_delay_ms(100);
	while (ADC_Conversion(2) != 255)					//while loop which detects black line using middle sensor so that the robot stops turning
	{
		left();
		velocity(80, 81);
		_delay_ms(2);
	}

	stop();
	_delay_ms(50);
	forward_untw(1, c);
	stop();
	_delay_ms(100);
	while (ADC_Conversion(2) != 255)					//while loop which detects black line using middle sensor so that the robot stops turning
	{
		right();
		velocity(81, 80);
		_delay_ms(2);
	}

	stop();
	_delay_ms(50);
	forward_untw(1, c);
	stop();
	_delay_ms(50);
	while (ADC_Conversion(2) != 255)					//while loop which detects black line using middle sensor so that the robot stops turning
	{
		left();
		velocity(80, 81);
		_delay_ms(2);
	}

	stop();
	_delay_ms(50);
	forward_untw(1, c);
	stop();
	_delay_ms(100);
	while (ADC_Conversion(2) != 255)					//while loop which detects black line using middle sensor so that the robot stops turning
	{
		right();
		velocity(81, 80);
		_delay_ms(2);
	}

	stop();
	_delay_ms(50);
	forward_untw(1, c);
	stop();
	_delay_ms(100);
	while (ADC_Conversion(2) != 255)					//while loop which detects black line using middle sensor so that the robot stops turning
	{
		left();
		velocity(80, 81);
		_delay_ms(2);
	}

	stop();
	_delay_ms(50);
	forward_untw(1, c);
	stop();
	_delay_ms(100);
	while (ADC_Conversion(2) != 255)					//while loop which detects black line using middle sensor so that the robot stops turning
	{
		right();
		velocity(81, 80);
		_delay_ms(2);
	}

	stop();
	_delay_ms(50);
	forward_wls(1);


	stop();
	_delay_ms(100);
}

/*
*
* Function Name: forward_zigzag_2110
* Input: node
* Output: void
* Logic: Uses white line sensors to go forward on zigzag lines by the number of nodes specified from nodes 21 to 10
* Example Call: forward_zigzag_2110(1); //Goes forward by one node on zigzag from nodes 21 to 10
*
*/
void forward_zigzag_2110(unsigned char node)
{
	int c = 47;
	forward_untw(1, 60);
	stop();
	_delay_ms(40);

	while (ADC_Conversion(2) != 255)					//while loop which detects black line using middle sensor so that the robot stops turning
	{
		right();
		velocity(81, 80);
		_delay_ms(2);
	}
	stop();
	_delay_ms(40);
	forward_untw(1, c);
	stop();
	_delay_ms(100);

	while (ADC_Conversion(2) != 255)					//while loop which detects black line using middle sensor so that the robot stops turning
	{
		left();
		velocity(80, 81);
		_delay_ms(2);
	}
	stop();
	_delay_ms(40);
	forward_untw(1, c);
	stop();
	_delay_ms(100);

	while (ADC_Conversion(2) != 255)					//while loop which detects black line using middle sensor so that the robot stops turning
	{
		right();
		velocity(81, 80);
		_delay_ms(2);
	}
	stop();
	_delay_ms(40);
	forward_untw(1, c);
	stop();
	_delay_ms(100);

	while (ADC_Conversion(2) != 255)					//while loop which detects black line using middle sensor so that the robot stops turning
	{
		left();
		velocity(80, 81);
		_delay_ms(2);
	}
	stop();
	_delay_ms(40);
	forward_untw(1, c);
	stop();
	_delay_ms(100);

	while (ADC_Conversion(2) != 255)					//while loop which detects black line using middle sensor so that the robot stops turning
	{
		right();
		velocity(81, 80);
		_delay_ms(2);
	}
	stop();
	_delay_ms(40);
	forward_untw(1, c);
	stop();
	_delay_ms(100);

	while (ADC_Conversion(2) != 255)					//while loop which detects black line using middle sensor so that the robot stops turning
	{
		left();
		velocity(80, 81);
		_delay_ms(2);
	}
	stop();
	_delay_ms(40);
	forward_untw(1, c);
	stop();
	_delay_ms(100);

	while (ADC_Conversion(2) != 255)					//while loop which detects black line using middle sensor so that the robot stops turning
	{
		right();
		velocity(81, 80);
		_delay_ms(2);
	}
	stop();
	_delay_ms(40);
	forward_untw(1, c);
	stop();
	_delay_ms(100);

	while (ADC_Conversion(2) != 255)					//while loop which detects black line using middle sensor so that the robot stops turning
	{
		left();
		velocity(80, 81);
		_delay_ms(2);
	}
	stop();
	_delay_ms(40);
	forward_wls(1);
	stop();
	_delay_ms(40);
}

/*
*
* Function Name: forward_inv
* Input: void
* Output: void
* Logic: Uses white line sensors to go forward on white and black lines by the number of nodes specified
* Example Call: forward_inv(1); //Goes forward by one node on any line black or white
*
*/
void forward_inv(void)
{
	unsigned char ls, ms, rs;
	int c = 0;
	int a = 0;														//local variable a which helps in getting feeback from different blocks of this function
	static_reorientation();
	static_reorientation();
	static_reorientation();
	static_reorientation();
	static_reorientation();
	do {															//main do while loop which helps the robot to cross the part of the track where black line inverts to white line
		ls = ADC_Conversion(1);										//sensor input
		ms = ADC_Conversion(2);
		rs = ADC_Conversion(3);
		//logging sensor values for debugging
		if (ls == 0 && ms == 255 && rs == 0)						//main code block which helps the robot to traverse black line just before the inversion and to also detect the inversion
		{
			forward();
			velocity(60, 60);
		}
		else if (ls == 0 && ms == 0 && rs == 255)					//making choice of movement on the basis of sensor movement
		{
			right();
			velocity(40, 40);
		}
		else if (ls == 255 && ms == 0 && rs == 0)
		{
			left();
			velocity(40, 40);
		}
		else if (ls == 255 && ms == 255 && rs == 0)
		{
			soft_left();
			velocity(0, 20);
		}
		else if (ls == 0 && ms == 255 && rs == 255)
		{
			soft_right();
			velocity(20, 0);
		}
		else if (ls == 255 && ms == 0 && rs == 255)					//if inversion is detected
		{
			a = 2;
			cout << "\nInversion Detected";
			stop();
			break;
		}
	} while (a == 0);												//if inversion is detected this do while loop breaks
	if (a == 2)														//code block which proceeds if inversion is detected
	{
		while (1)													//main while loop
		{
			ls = ADC_Conversion(1);									//sensor input
			ms = ADC_Conversion(2);
			rs = ADC_Conversion(3);
			//logging sensor values for debugging
			if (ls == 0 && ms == 255 && rs == 0)					//if black line is again detected just before the node this shows that inversion track is crossed
			{
				a = 3;
				cout << "\nBlack Line Detected.";
				stop();
				break;
			}
			else if (ls == 255 && ms == 255 && rs == 0)				//making choice of movement on the basis of sensor movement which is now totally inverted of the algorithm written in forward_wls
			{
				right();
				velocity(40, 40);
			}
			else if (ls == 0 && ms == 255 && rs == 255)
			{
				left();
				velocity(40, 40);
			}
			else if (ls == 255 && ms == 0 && rs == 255)
			{
				c = 0;
				forward();
				velocity(60, 60);

			}
			else if (ls == 255 && ms == 255 && rs == 255)			//else if block which makes the robot to step backwards a liitle bit so that it can sense the white line if all the sensors are off the white line
			{
				back();
				_delay_ms(5);
			}
			else if ((ls == 0 && ms == 0 && rs == 0) || (ls == 0 && ms == 0 && rs == 255) || (ls == 255 && ms == 0 && rs == 0))			//else if block which makes the robot to step backwards a liitle bit so that it can sense the white line if all the sensors are off the white line
			{
				c++;
				cout << c;
				_delay_ms(5);
				if (c > 40)
				{
					cout << endl << "\nWhite Node Detected.";
					forward();													//code to move the robot tiny bit so that it is placed on the node
					velocity(255, 255);
					_delay_ms(300);
					right_turn_wwls();
					left_turn_wwls();
					c = 0;
				}
			}

		}
	}
	if (a == 3)													//code block which proceeds if inversion is ended and black line is again detected
	{
		while (1)												//infinte loop which is breaked only when a node is detected
		{
			ls = ADC_Conversion(1);								//sensor input
			ms = ADC_Conversion(2);
			rs = ADC_Conversion(3);

			if (ls == 0 && ms == 255 && rs == 0)				//making choice of movement on the basis of sensor movement
			{
				forward();
				velocity(60, 60);
			}
			else if (ls == 0 && ms == 0 && rs == 255)
			{
				right();
				velocity(40, 40);
			}
			else if (ls == 255 && ms == 0 && rs == 0)
			{
				left();
				velocity(40, 40);
			}
			else if (ls == 255 && ms == 255 && rs == 0)
			{
				soft_left();
				velocity(0, 20);
			}
			else if (ls == 0 && ms == 255 && rs == 255)
			{
				soft_right();
				velocity(20, 0);
			}
			else if (ls == 255 && ms == 255 && rs == 255)		//else block which helps in detecting node
			{
				a = 4;
				cout << "\nNode Detected.";
				stop();
				break;
			}

		}
	}
	if (a == 4)													//code block which proceeds if node is detected
	{
		forward();												//code to move the robot tiny bit so that it is placed on the node
		velocity(255, 255);
		_delay_ms(300);
	}
}

/*
*
* Function Name: left_turn_wls
* Input: void
* Output: void
* Logic: Uses white line sensors to turn left until black line is encountered
* Example Call: left_turn_wls(); //Turns right until black line is encountered
*
*/
void left_turn_wls(void)
{
	left();												//code which helps the robot to ignore the black line which is going straight so that it can focus on line which is going to the left
	_delay_ms(250);
	while (ADC_Conversion(2) != 255)					//while loop which detects black line using middle sensor so that the robot stops turning
	{
		left();
		velocity(127, 127);
		_delay_ms(2);
	}
}

/*
*
* Function Name: right_turn_wls
* Input: void
* Output: void
* Logic: Uses white line sensors to turn right until black line is encountered
* Example Call: right_turn_wls(); //Turns right until black line is encountered
*/
void right_turn_wls(void)
{
	right();											//code which helps the robot to ignore the black line which is going straight so that it can focus on line which is going to the right
	_delay_ms(250);
	while (ADC_Conversion(2) != 255)					//while loop which detects black line using middle sensor so that the robot stops turning
	{
		right();
		velocity(127, 127);
		_delay_ms(2);
	}
}

/*
*
* Function Name: forward_inv_1516
* Input: void
* Output: void
* Logic: Uses white line sensors to go forward on white and black lines by the number of nodes specified from 15 to 16
* Example Call: forward_inv_1516(1); //Goes forward by one node on any line black or white from 15 to 16
*
*/
void forward_inv_1516(void)
{
	unsigned char ls, ms, rs;
	int a = 0;														//local variable a which helps in getting feeback from different blocks of this function
	static_reorientation();
	static_reorientation();
	static_reorientation();
	do {															//main do while loop which helps the robot to cross the part of the track where black line inverts to white line
		ls = ADC_Conversion(1);										//sensor input
		ms = ADC_Conversion(2);
		rs = ADC_Conversion(3);
		//logging sensor values for debugging
		if (ls == 0 && ms == 255 && rs == 0)						//main code block which helps the robot to traverse black line just before the inversion and to also detect the inversion
		{
			forward();
			velocity(60, 60);
		}
		else if (ls == 0 && ms == 0 && rs == 255)					//making choice of movement on the basis of sensor movement
		{
			right();
			velocity(40, 40);
		}
		else if (ls == 255 && ms == 0 && rs == 0)
		{
			left();
			velocity(40, 40);
		}
		else if (ls == 255 && ms == 255 && rs == 0)
		{
			soft_left();
			velocity(0, 20);
		}
		else if (ls == 0 && ms == 255 && rs == 255)
		{
			soft_right();
			velocity(20, 0);
		}
		else if (ls == 255 && ms == 0 && rs == 255)					//if inversion is detected
		{
			a = 2;
			cout << "\nInversion Detected";
			stop();
			break;
		}
	} while (a == 0);												//if inversion is detected this do while loop breaks
	if (a == 2)														//code block which proceeds if inversion is detected
	{
		while (1)													//main while loop
		{
			ls = ADC_Conversion(1);									//sensor input
			ms = ADC_Conversion(2);
			rs = ADC_Conversion(3);
			//logging sensor values for debugging
			if (ls == 0 && ms == 255 && rs == 0)					//if black line is again detected just before the node this shows that inversion track is crossed
			{
				a = 3;
				cout << "\nBlack Line Detected.";
				stop();
				break;
			}
			else if (ls == 255 && ms == 255 && rs == 0)				//making choice of movement on the basis of sensor movement which is now totally inverted of the algorithm written in forward_wls
			{
				right();
				velocity(40, 40);
			}
			else if (ls == 0 && ms == 255 && rs == 255)
			{
				left();
				velocity(40, 40);
			}
			else if (ls == 255 && ms == 0 && rs == 255)
			{
				forward();
				velocity(60, 60);

			}
			else if (ls == 0 && ms == 0 && rs == 255)					//making choice of movement on the basis of sensor movement
			{
				left();
				velocity(40, 40);
			}
			else if (ls == 255 && ms == 0 && rs == 0)
			{
				right();
				velocity(40, 40);
			}

			else if (ls == 0 && ms == 0 && rs == 0)
			{
				cout << endl << "all white";
				forward();												//code to move the robot tiny bit so that it is placed on the node
				velocity(255, 255);
				_delay_ms(350);
				stop();
				a = 5;
				break;

			}

		}
	}
	if (a = 5)
	{
		cout << endl << "ready to turn";

	}
}

/*
*
* Function Name: forward_inv_1617
* Input: void
* Output: void
* Logic: Uses white line sensors to go forward on white and black lines by the number of nodes specified from 16 to 17
* Example Call: forward_inv_1617(1); //Goes forward by one node on any line black or white from 16 to 17
*
*/
void forward_inv_1617(void)
{
	unsigned char ls, ms, rs;
	int a = 2;											//local variable a which helps in getting feeback from different blocks of this function
	//static_reorientation_inv();
	//static_reorientation_inv();
	//static_reorientation_inv();
	if (a == 2)														//code block which proceeds if inversion is detected
	{
		while (1)													//main while loop
		{
			ls = ADC_Conversion(1);									//sensor input
			ms = ADC_Conversion(2);
			rs = ADC_Conversion(3);
			//logging sensor values for debugging
			if (ls == 0 && ms == 255 && rs == 0)					//if black line is again detected just before the node this shows that inversion track is crossed
			{
				a = 3;
				cout << "\nBlack Line Detected.";
				stop();
				break;
			}
			else if (ls == 255 && ms == 255 && rs == 0)				//making choice of movement on the basis of sensor movement which is now totally inverted of the algorithm written in forward_wls
			{
				right();
				velocity(40, 40);
			}
			else if (ls == 0 && ms == 255 && rs == 255)
			{
				left();
				velocity(40, 40);
			}
			else if (ls == 255 && ms == 0 && rs == 255)
			{
				forward();
				velocity(60, 60);

			}
			else if (ls == 0 && ms == 0 && rs == 255)					//making choice of movement on the basis of sensor movement
			{
				left();
				velocity(40, 40);
			}
			else if (ls == 255 && ms == 0 && rs == 0)
			{
				right();
				velocity(40, 40);
			}


		}
	}
	if (a == 3)													//code block which proceeds if inversion is ended and black line is again detected
	{
		while (1)												//infinte loop which is breaked only when a node is detected
		{
			ls = ADC_Conversion(1);								//sensor input
			ms = ADC_Conversion(2);
			rs = ADC_Conversion(3);

			if (ls == 0 && ms == 255 && rs == 0)				//making choice of movement on the basis of sensor movement
			{
				forward();
				velocity(60, 60);
			}
			else if (ls == 0 && ms == 0 && rs == 255)
			{
				right();
				velocity(40, 40);
			}
			else if (ls == 255 && ms == 0 && rs == 0)
			{
				left();
				velocity(40, 40);
			}
			else if (ls == 255 && ms == 255 && rs == 0)
			{
				soft_left();
				velocity(0, 20);
			}
			else if (ls == 0 && ms == 255 && rs == 255)
			{
				soft_right();
				velocity(20, 0);
			}
			else if (ls == 255 && ms == 255 && rs == 255)		//else block which helps in detecting node
			{
				a = 4;
				cout << "\nNode Detected.";
				stop();
				break;
			}

		}
	}
	if (a == 4)													//code block which proceeds if node is detected
	{
		forward();												//code to move the robot tiny bit so that it is placed on the node
		velocity(255, 255);
		_delay_ms(300);
	}
	if (a = 5)
	{
		cout << endl << "ready to turn";

	}
}

/*
*
* Function Name: forward_inv_1716
* Input: void
* Output: void
* Logic: Uses white line sensors to go forward on white and black lines by the number of nodes specified from 17 to 16
* Example Call: forward_inv_1716(1); //Goes forward by one node on any line black or white from 17 to 16
*
*/
void forward_inv_1716(void)
{
	unsigned char ls, ms, rs;
	int a = 0;														//local variable a which helps in getting feeback from different blocks of this function
	static_reorientation();
	do {															//main do while loop which helps the robot to cross the part of the track where black line inverts to white line
		ls = ADC_Conversion(1);										//sensor input
		ms = ADC_Conversion(2);
		rs = ADC_Conversion(3);
		//logging sensor values for debugging
		if (ls == 0 && ms == 255 && rs == 0)						//main code block which helps the robot to traverse black line just before the inversion and to also detect the inversion
		{
			forward();
			velocity(60, 60);
		}
		else if (ls == 0 && ms == 0 && rs == 255)					//making choice of movement on the basis of sensor movement
		{
			right();
			velocity(40, 40);
		}
		else if (ls == 255 && ms == 0 && rs == 0)
		{
			left();
			velocity(40, 40);
		}
		else if (ls == 255 && ms == 255 && rs == 0)
		{
			soft_left();
			velocity(0, 20);
		}
		else if (ls == 0 && ms == 255 && rs == 255)
		{
			soft_right();
			velocity(20, 0);
		}
		else if (ls == 255 && ms == 0 && rs == 255)					//if inversion is detected
		{
			a = 2;
			cout << "\nInversion Detected";
			stop();
			break;
		}
	} while (a == 0);												//if inversion is detected this do while loop breaks
	if (a == 2)														//code block which proceeds if inversion is detected
	{
		while (1)													//main while loop
		{
			ls = ADC_Conversion(1);									//sensor input
			ms = ADC_Conversion(2);
			rs = ADC_Conversion(3);
			//logging sensor values for debugging
			if (ls == 0 && ms == 255 && rs == 0)					//if black line is again detected just before the node this shows that inversion track is crossed
			{
				a = 3;
				cout << "\nBlack Line Detected.";
				stop();
				break;
			}
			else if (ls == 255 && ms == 255 && rs == 0)				//making choice of movement on the basis of sensor movement which is now totally inverted of the algorithm written in forward_wls
			{
				right();
				velocity(40, 40);
			}
			else if (ls == 0 && ms == 255 && rs == 255)
			{
				left();
				velocity(40, 40);
			}
			else if (ls == 255 && ms == 0 && rs == 255)
			{
				forward();
				velocity(60, 60);

			}
			else if (ls == 0 && ms == 0 && rs == 255)					//making choice of movement on the basis of sensor movement
			{
				left();
				velocity(40, 40);
			}
			else if (ls == 255 && ms == 0 && rs == 0)
			{
				right();
				velocity(40, 40);
			}

			else if (ls == 0 && ms == 0 && rs == 0)
			{
				cout << endl << "all white";
				forward();												//code to move the robot tiny bit so that it is placed on the node
				velocity(255, 255);
				_delay_ms(350);
				stop();
				a = 5;
				break;


			}

		}
	}
	if (a = 5)
	{
		cout << endl << "ready to turn";
		//turn right
		//go forward and place
		//turn 360
		//comeback to white node
		//turn right
		//move forward
	}
}
/*
*
* Function Name: forward_inv_1615
* Input: void
* Output: void
* Logic: Uses white line sensors to go forward on white and black lines by the number of nodes specified from 16 to 15
* Example Call: forward_inv_1615(1); //Goes forward by one node on any line black or white from 16 to 15
*
*/
void forward_inv_1615(void)
{
	unsigned char ls, ms, rs;
	int a = 2;											//local variable a which helps in getting feeback from different blocks of this function
	//static_reorientation_inv();
	//static_reorientation_inv();
	//static_reorientation_inv();
	if (a == 2)														//code block which proceeds if inversion is detected
	{
		while (1)													//main while loop
		{
			ls = ADC_Conversion(1);									//sensor input
			ms = ADC_Conversion(2);
			rs = ADC_Conversion(3);
			//logging sensor values for debugging
			if (ls == 0 && ms == 255 && rs == 0)					//if black line is again detected just before the node this shows that inversion track is crossed
			{
				a = 3;
				cout << "\nBlack Line Detected.";
				stop();
				break;
			}
			else if (ls == 255 && ms == 255 && rs == 0)				//making choice of movement on the basis of sensor movement which is now totally inverted of the algorithm written in forward_wls
			{
				right();
				velocity(40, 40);
			}
			else if (ls == 0 && ms == 255 && rs == 255)
			{
				left();
				velocity(40, 40);
			}
			else if (ls == 255 && ms == 0 && rs == 255)
			{
				forward();
				velocity(60, 60);

			}
			else if (ls == 0 && ms == 0 && rs == 255)					//making choice of movement on the basis of sensor movement
			{
				left();
				velocity(40, 40);
			}
			else if (ls == 255 && ms == 0 && rs == 0)
			{
				right();
				velocity(40, 40);
			}

			else if (ls == 0 && ms == 0 && rs == 0)
			{
				cout << endl << "all white";
				stop();
				a = 5;
				break;


			}

		}
	}
	if (a == 3)													//code block which proceeds if inversion is ended and black line is again detected
	{
		while (1)												//infinte loop which is breaked only when a node is detected
		{
			ls = ADC_Conversion(1);								//sensor input
			ms = ADC_Conversion(2);
			rs = ADC_Conversion(3);

			if (ls == 0 && ms == 255 && rs == 0)				//making choice of movement on the basis of sensor movement
			{
				forward();
				velocity(60, 60);
			}
			else if (ls == 0 && ms == 0 && rs == 255)
			{
				right();
				velocity(40, 40);
			}
			else if (ls == 255 && ms == 0 && rs == 0)
			{
				left();
				velocity(40, 40);
			}
			else if (ls == 255 && ms == 255 && rs == 0)
			{
				soft_left();
				velocity(0, 20);
			}
			else if (ls == 0 && ms == 255 && rs == 255)
			{
				soft_right();
				velocity(20, 0);
			}
			else if (ls == 255 && ms == 255 && rs == 255)		//else block which helps in detecting node
			{
				a = 4;
				cout << "\nNode Detected.";
				stop();
				break;
			}

		}
	}
	if (a == 4)													//code block which proceeds if node is detected
	{
		forward();												//code to move the robot tiny bit so that it is placed on the node
		velocity(255, 255);
		_delay_ms(300);
	}
	if (a = 5)
	{
		cout << endl << "ready to turn";
		//turn right
		//go forward and place
		//turn 360
		//comeback to white node
		//turn right
		//move forward
	}
}

/*
*
* Function Name: traverse
* Input: vector array, current face direction, initail node
* Output: void
* Logic: uses direction knowledge and the distance array generated by dijkstra to traverse to any node from the current node through shortest path
* Example Call: traverse(path,n,12); //uses direction knowledge and the distance array generated by dijkstra to traverse to any node from the current node through shortest path
*
*/
void traverse(const vector<int>& path, char face, int u)
{
	int a = 0;
	int ps = path.size();
	for (int i = 0; i < ps - 1; i++)
	{
		if ((path[i] == 5 && path[i + 1] == 26)
			|| (path[i] == 26 && path[i + 1] == 5))				//walls
		{

			for (int a = 0; a < 4; a++)
			{
				if (movement_array[path[i]][a] == path[i + 1])
				{
					cout << movement_array[path[i]][a] << endl;
					if (a == 0)
					{
						fdir = 'n';
					}
					else if (a == 1)
					{
						fdir = 'e';
					}
					else if (a == 2)
					{
						fdir = 's';
					}
					else if (a == 3)
					{
						fdir = 'w';
					}
				}
			}
			if (face == 'n' && fdir == 'n')
			{
				static_reorientation();
				forward_walls();
				face = fdir;
				cout << "Current Direction" << face << endl;
			}
			else if (face == 'n' && fdir == 'e')
			{
				right_turn_wls();
				static_reorientation();
				forward_walls();

				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 's')
			{
				right_turn_wls();
				right_turn_wls();
				static_reorientation();
				forward_walls();
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 'w')
			{
				left_turn_wls();
				static_reorientation();
				forward_walls();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'e')
			{
				static_reorientation();
				forward_walls();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 's')
			{
				right_turn_wls();
				static_reorientation();
				forward_walls();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'w')
			{
				right_turn_wls();
				right_turn_wls();
				static_reorientation();
				forward_walls();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'n')
			{
				left_turn_wls();
				static_reorientation();
				forward_walls();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 's')
			{
				static_reorientation();
				forward_walls();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'w')
			{
				right_turn_wls();
				static_reorientation();
				forward_walls();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'n')
			{
				right_turn_wls();
				right_turn_wls();
				static_reorientation();
				forward_walls();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'e')
			{
				left_turn_wls();
				static_reorientation();
				forward_walls();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'w')
			{
				static_reorientation();
				forward_walls();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'n')
			{
				right_turn_wls();
				static_reorientation();
				forward_walls();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'e')
			{
				right_turn_wls();
				right_turn_wls();
				static_reorientation();
				forward_walls();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 's')
			{
				left_turn_wls();
				static_reorientation();
				forward_walls();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
		}
		else if ((path[i] == 10 && path[i + 1] == 21))				//zigzag 1021
		{
			for (int a = 0; a < 4; a++)
			{
				if (movement_array[path[i]][a] == path[i + 1])
				{
					cout << movement_array[path[i]][a] << endl;
					if (a == 0)
					{
						fdir = 'n';
					}
					else if (a == 1)
					{
						fdir = 'e';
					}
					else if (a == 2)
					{
						fdir = 's';
					}
					else if (a == 3)
					{
						fdir = 'w';
					}
				}
			}
			if (face == 'n' && fdir == 'n')
			{
				forward_zigzag_1021(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 'e')
			{
				right_turn_wls();
				forward_zigzag_1021(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 's')
			{
				right_turn_wls();
				right_turn_wls();
				forward_zigzag_1021(1);
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 'w')
			{
				left_turn_wls();
				forward_zigzag_1021(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'e')
			{
				forward_zigzag_1021(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 's')
			{
				right_turn_wls();
				forward_zigzag_1021(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'w')
			{
				right_turn_wls();
				right_turn_wls();
				forward_zigzag_1021(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'n')
			{
				left_turn_wls();
				forward_zigzag_1021(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 's')
			{
				forward_zigzag_1021(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'w')
			{
				right_turn_wls();
				forward_zigzag_1021(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'n')
			{
				right_turn_wls();
				right_turn_wls();
				forward_zigzag_1021(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'e')
			{
				left_turn_wls();
				forward_zigzag_1021(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'w')
			{
				forward_zigzag_1021(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'n')
			{
				right_turn_wls();
				forward_zigzag_1021(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'e')
			{
				right_turn_wls();
				right_turn_wls();
				forward_zigzag_1021(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 's')
			{
				left_turn_wls();
				forward_zigzag_1021(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
		}
		else if ((path[i] == 21 && path[i + 1] == 10))					//zigzag 2110
		{
			for (int a = 0; a < 4; a++)
			{
				if (movement_array[path[i]][a] == path[i + 1])
				{
					cout << movement_array[path[i]][a] << endl;
					if (a == 0)
					{
						fdir = 'n';
					}
					else if (a == 1)
					{
						fdir = 'e';
					}
					else if (a == 2)
					{
						fdir = 's';
					}
					else if (a == 3)
					{
						fdir = 'w';
					}
				}
			}
			if (face == 'n' && fdir == 'n')
			{
				forward_zigzag_2110(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 'e')
			{
				right_turn_wls();
				forward_zigzag_2110(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 's')
			{
				right_turn_wls();
				right_turn_wls();
				forward_zigzag_2110(1);
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 'w')
			{
				left_turn_wls();
				forward_zigzag_2110(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'e')
			{
				forward_zigzag_2110(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 's')
			{
				right_turn_wls();
				forward_zigzag_2110(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'w')
			{
				right_turn_wls();
				right_turn_wls();
				forward_zigzag_2110(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'n')
			{
				left_turn_wls();
				forward_zigzag_2110(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 's')
			{
				forward_zigzag_2110(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'w')
			{
				right_turn_wls();
				forward_zigzag_2110(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'n')
			{
				right_turn_wls();
				right_turn_wls();
				forward_zigzag_2110(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'e')
			{
				left_turn_wls();
				forward_zigzag_2110(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'w')
			{
				forward_zigzag_2110(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'n')
			{
				right_turn_wls();
				forward_zigzag_2110(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'e')
			{
				right_turn_wls();
				right_turn_wls();
				forward_zigzag_2110(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 's')
			{
				left_turn_wls();
				forward_zigzag_2110(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
		}
		else if ((path[i] == 15 && path[i + 1] == 16))											//inversion 15 - 16
		{
			for (int a = 0; a < 4; a++)
			{
				if (movement_array[path[i]][a] == path[i + 1])
				{
					cout << movement_array[path[i]][a] << endl;
					if (a == 0)
					{
						fdir = 'n';
					}
					else if (a == 1)
					{
						fdir = 'e';
					}
					else if (a == 2)
					{
						fdir = 's';
					}
					else if (a == 3)
					{
						fdir = 'w';
					}
				}
			}
			if (face == 'n' && fdir == 'n')
			{
				forward_inv_1516();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 'e')
			{
				right_turn_wls();
				forward_inv_1516();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 's')
			{
				right_turn_wls();
				right_turn_wls();
				forward_inv_1516();
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 'w')
			{
				left_turn_wls();
				forward_inv_1516();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'e')
			{
				forward_inv_1516();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 's')
			{
				right_turn_wls();
				forward_inv_1516();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'w')
			{
				right_turn_wls();
				right_turn_wls();
				forward_inv_1516();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'n')
			{
				left_turn_wls();
				forward_inv_1516();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 's')
			{
				forward_inv_1516();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'w')
			{
				right_turn_wls();
				forward_inv_1516();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'n')
			{
				right_turn_wls();
				right_turn_wls();
				forward_inv_1516();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'e')
			{
				left_turn_wls();
				forward_inv_1516();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'w')
			{
				forward_inv_1516();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'n')
			{
				right_turn_wls();
				forward_inv_1516();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'e')
			{
				right_turn_wls();
				right_turn_wls();
				forward_inv_1516();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 's')
			{
				left_turn_wls();
				forward_inv_1516();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
		}
		else if (path[i] == 16 && path[i + 1] == 15)																//inversion 16 - 15
		{
			for (int a = 0; a < 4; a++)
			{
				if (movement_array[path[i]][a] == path[i + 1])
				{
					cout << movement_array[path[i]][a] << endl;
					if (a == 0)
					{
						fdir = 'n';
					}
					else if (a == 1)
					{
						fdir = 'e';
					}
					else if (a == 2)
					{
						fdir = 's';
					}
					else if (a == 3)
					{
						fdir = 'w';
					}
				}
			}
			if (face == 'n' && fdir == 'n')
			{
				forward_inv_1615();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 'e')
			{
				right_turn_inv_wls();
				forward_inv_1615();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 's')
			{
				right_turn_inv_wls();
				right_turn_inv_wls();
				forward_inv_1615();
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 'w')
			{
				left_turn_inv_wls();
				forward_inv_1615();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'e')
			{
				forward_inv_1615();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 's')
			{
				right_turn_inv_wls();
				forward_inv_1615();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'w')
			{
				right_turn_inv_wls();
				right_turn_inv_wls();
				forward_inv_1615();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'n')
			{
				left_turn_inv_wls();
				forward_inv_1615();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 's')
			{
				forward_inv_1615();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'w')
			{
				right_turn_inv_wls();
				forward_inv_1615();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'n')
			{
				right_turn_inv_wls();
				right_turn_inv_wls();
				forward_inv_1615();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'e')
			{
				left_turn_inv_wls();
				forward_inv_1615();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'w')
			{
				forward_inv_1615();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'n')
			{
				right_turn_inv_wls();
				forward_inv_1615();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'e')
			{
				right_turn_inv_wls();
				right_turn_inv_wls();
				forward_inv_1615();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 's')
			{
				left_turn_inv_wls();
				forward_inv_1615();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
		}
		else if (path[i] == 16 && path[i + 1] == 17)										//inversion 16 - 17
		{
			for (int a = 0; a < 4; a++)
			{
				if (movement_array[path[i]][a] == path[i + 1])
				{
					cout << movement_array[path[i]][a] << endl;
					if (a == 0)
					{
						fdir = 'n';
					}
					else if (a == 1)
					{
						fdir = 'e';
					}
					else if (a == 2)
					{
						fdir = 's';
					}
					else if (a == 3)
					{
						fdir = 'w';
					}
				}
			}
			if (face == 'n' && fdir == 'n')
			{
				forward_inv_1617();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 'e')
			{
				right_turn_inv_wls();
				forward_inv_1617();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 's')
			{
				right_turn_inv_wls();
				right_turn_inv_wls();
				forward_inv_1617();
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 'w')
			{
				left_turn_inv_wls();
				forward_inv_1617();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'e')
			{
				forward_inv_1617();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 's')
			{
				right_turn_inv_wls();
				forward_inv_1617();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'w')
			{
				right_turn_inv_wls();
				right_turn_inv_wls();
				forward_inv_1617();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'n')
			{
				left_turn_inv_wls();
				forward_inv_1617();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 's')
			{
				forward_inv_1617();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'w')
			{
				right_turn_inv_wls();
				forward_inv_1617();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'n')
			{
				right_turn_inv_wls();
				right_turn_inv_wls();
				forward_inv_1617();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'e')
			{
				left_turn_inv_wls();
				forward_inv_1617();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'w')
			{
				forward_inv_1617();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'n')
			{
				right_turn_inv_wls();
				forward_inv_1617();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'e')
			{
				right_turn_inv_wls();
				right_turn_inv_wls();
				forward_inv_1617();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 's')
			{
				left_turn_inv_wls();
				forward_inv_1617();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
		}
		else if (path[i] == 17 && path[i + 1] == 16)														//inversion 17 - 16
		{
			for (int a = 0; a < 4; a++)
			{
				if (movement_array[path[i]][a] == path[i + 1])
				{
					cout << movement_array[path[i]][a] << endl;
					if (a == 0)
					{
						fdir = 'n';
					}
					else if (a == 1)
					{
						fdir = 'e';
					}
					else if (a == 2)
					{
						fdir = 's';
					}
					else if (a == 3)
					{
						fdir = 'w';
					}
				}
			}
			if (face == 'n' && fdir == 'n')
			{
				forward_inv_1716();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 'e')
			{
				right_turn_wls();
				forward_inv_1716();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 's')
			{
				right_turn_wls();
				right_turn_wls();
				forward_inv_1716();
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 'w')
			{
				left_turn_wls();
				forward_inv_1716();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'e')
			{
				forward_inv_1716();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 's')
			{
				right_turn_wls();
				forward_inv_1716();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'w')
			{
				right_turn_wls();
				right_turn_wls();
				forward_inv_1716();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'n')
			{
				left_turn_wls();
				forward_inv_1716();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 's')
			{
				forward_inv_1716();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'w')
			{
				right_turn_wls();
				forward_inv_1716();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'n')
			{
				right_turn_wls();
				right_turn_wls();
				forward_inv_1716();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'e')
			{
				left_turn_wls();
				forward_inv_1716();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'w')
			{
				forward_inv_1716();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'n')
			{
				right_turn_wls();
				forward_inv_1716();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'e')
			{
				right_turn_wls();
				right_turn_wls();
				forward_inv_1716();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 's')
			{
				left_turn_wls();
				forward_inv_1716();
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
		}
		else if ((path[i] == 21 && path[i + 1] == 22)
			|| (path[i] == 26 && path[i + 1] == 27)
			|| (path[i] == 5 && path[i + 1] == 6)
			|| (path[i] == 10 && path[i + 1] == 11))				//just before houses
		{
			for (int a = 0; a < 4; a++)
			{
				if (movement_array[path[i]][a] == path[i + 1])
				{
					cout << movement_array[path[i]][a] << endl;
					if (a == 0)
					{
						fdir = 'n';
					}
					else if (a == 1)
					{
						fdir = 'e';
					}
					else if (a == 2)
					{
						fdir = 's';
					}
					else if (a == 3)
					{
						fdir = 'w';
					}
				}
			}
			if (face == 'n' && fdir == 'n')
			{
				forward_wls_house(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 'e')
			{
				right_turn_wls();
				forward_wls_house(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 's')
			{
				right_turn_wls();
				right_turn_wls();
				forward_wls_house(1);
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 'w')
			{
				left_turn_wls();
				forward_wls_house(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'e')
			{
				forward_wls_house(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 's')
			{
				right_turn_wls();
				forward_wls_house(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'w')
			{
				right_turn_wls();
				right_turn_wls();
				forward_wls_house(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'n')
			{
				left_turn_wls();
				forward_wls_house(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 's')
			{
				forward_wls_house(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'w')
			{
				right_turn_wls();
				forward_wls_house(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'n')
			{
				right_turn_wls();
				right_turn_wls();
				forward_wls_house(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'e')
			{
				left_turn_wls();
				forward_wls_house(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'w')
			{
				forward_wls_house(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'n')
			{
				right_turn_wls();
				forward_wls_house(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'e')
			{
				right_turn_wls();
				right_turn_wls();
				forward_wls_house(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 's')
			{
				left_turn_wls();
				forward_wls_house(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
		}
		else															//normal line follow
		{
			for (int a = 0; a < 4; a++)
			{
				if (movement_array[path[i]][a] == path[i + 1])
				{
					cout << movement_array[path[i]][a] << endl;
					if (a == 0)
					{
						fdir = 'n';
					}
					else if (a == 1)
					{
						fdir = 'e';
					}
					else if (a == 2)
					{
						fdir = 's';
					}
					else if (a == 3)
					{
						fdir = 'w';
					}
				}
			}
			if (face == 'n' && fdir == 'n')
			{
				forward_wls(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 'e')
			{
				right_turn_wls();
				forward_wls(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 's')
			{
				right_turn_wls();
				right_turn_wls();
				forward_wls(1);
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'n' && fdir == 'w')
			{
				left_turn_wls();
				forward_wls(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'e')
			{
				forward_wls(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 's')
			{
				right_turn_wls();
				forward_wls(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'w')
			{
				right_turn_wls();
				right_turn_wls();
				forward_wls(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'e' && fdir == 'n')
			{
				left_turn_wls();
				forward_wls(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 's')
			{
				forward_wls(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'w')
			{
				right_turn_wls();
				forward_wls(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'n')
			{
				right_turn_wls();
				right_turn_wls();
				forward_wls(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 's' && fdir == 'e')
			{
				left_turn_wls();
				forward_wls(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'w')
			{
				forward_wls(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'n')
			{
				right_turn_wls();
				forward_wls(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 'e')
			{
				right_turn_wls();
				right_turn_wls();
				forward_wls(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
			else if (face == 'w' && fdir == 's')
			{
				left_turn_wls();
				forward_wls(1);
				face = fdir;
				cout << "Current Direction " << face << endl;
			}
		}
	}
	cout << "Traverse Completed!" << endl;
}

/*
*
* Function Name: dist_comp
* Input: x,y
* Output: void
* Logic: compares distance from current node to two nodes
* Example Call: dist_comp(h1,14); //compares distance from current node to h1 and to 14
*
*/
vector<int> dist_comp(int x, int y)
{
	vector<int> path;
	if (dis[x] <= dis[y])
	{
		if (u != x)
		{
			int j = x;
			path.push_back(x);
			do {
				j = pre[j];
				path.push_back(j);
			} while (j != u);
		}
		cout << '\n';
		reverse(begin(path), end(path));
		print(path);
		u = x;
		cout << "Distance Comparision Completed!" << endl;
		return path;

	}
	else
	{
		if (u != y)
		{
			int j = y;
			path.push_back(y);
			do {
				j = pre[j];
				path.push_back(j);
			} while (j != u);
		}
		cout << '\n';
		reverse(begin(path), end(path));
		print(path);
		u = y;
		cout << "Distance Comparision Completed!" << endl;
		return path;
	}
}

/*
*
* Function Name: e_shape
* Input: void
* Output: void
* Logic: Use this function to make the robot trace a e shape path on the arena
* Example Call: e_shape();
*/
void e_shape(void)
{
	forward_wls(1);										//calling forward_wls and right_turn_wls to complete the e-shape
	right_turn_wls();
	forward_wls(1);
	forward_wls(1);
	right_turn_wls();
	forward_wls(1);
	right_turn_wls();
	forward_wls(1);
	right_turn_wls();
	forward_wls(1);
}


/*
*
* Function Name: Task_1_1
* Input: void
* Output: void
* Logic: Use this function to encapsulate your Task 1.1 logic
* Example Call: Task_1_1();
*/
void Task_1_1(void)
{
	//forward_wls(1);									//calling forward_wls, left_turn_wls and right_turn_wls to complete the task1.1
	//cout << "\nForward 1 Node";
	//right_turn_wls();
	//cout << "\n1 Right Node";
	//forward_wls(1);
	//cout << "\nForward 2 Node";
	//forward_wls(1);
	//cout << "\nForward 3 Node";
	//forward_wls(1);
	//cout << "\nForward 4 Node";
	//forward_wls(1);
	//cout << "\nForward 5 Node";
	//left_turn_wls();
	//cout << "\n5 Left Node";
	//forward_wls(1);
	//cout << "\nForward 6 Node";
	//left_turn_wls();
	//cout << "\n6 Left Node";
	//forward_wls(1);
	//cout << "\nForward 7 Node";
	//right_turn_wls();
	//cout << "\n7 Right Node";
	//forward_wls(1);
	//cout << "\nForward 8 Node";
	//left_turn_wls();
	//cout << "\n8 Left Node";
	//forward_wls(1);
	//cout << "\nForward 9 Node";
	//right_turn_wls();
	//cout << "\n9 Right Node";
	//forward_zigzag(1);								//calling forward_zigzag when needed
	//cout << "\nForward 10 Node";
	//left_turn_wls();
	//cout << "\n10 Left Node";
	//forward_wls(1);
	//cout << "\nForward 11 Node";
	//right_turn_wls();
	//cout << "\n11 Right Node";
	//forward_wls(1);
	//cout << "\nForward 12 Node";
	//left_turn_wls();
	//cout << "\n12 Left Node";
	//forward_wls(1);
	//cout << "\nForward 13 Node";
	//right_turn_wls();
	//cout << "\n13 Right Node";
	//forward_inv();									//calling forward_inv when needed
	//cout << "\nForward 14 Node";
	//right_turn_wls();
	//cout << "\n14 Right Node";
	//forward_wls(1);
	//cout << "\nForward 15 Node";
	//left_turn_wls();
	//cout << "\n15 Left Node";
	//forward_wls(1);
	//cout << "\nForward till Goal!";
	////Goal is Reached!

}

/*
*
* Function Name: Task_1_2
* Input: void
* Output: void
* Logic: Use this function to encapsulate your Task 1.2 logic
* Example Call: Task_1_2();
*/
void Task_1_2(void)
{
	forward_wls(1);
	u = 0;
	face = 's';
	right_turn_wls();
	u = 0;
	face = 'w';
	forward_wls(1);
	u = 1;
	face = 'w';
	right_turn_wls();
	u = 1;
	face = 'n';
	forward_wls(1);
	u = 2;
	face = 'n';
	right_turn_wls();
	u = 2;
	face = 'e';
	forward_wls(1);
	u = 4;
	face = 'e';
	proximity_analysis();				//picking 1st block
	dijkstra(G, n, u);
	vector<int> path;
	path = dist_comp(h5, h4);
	traverse(path, face, u);
	fplace();							//placing 1st block
	right_turn_wls();
	dijkstra(G, n, u);
	path = dist_comp(20, 20);
	traverse(path, face, u);
	proximity_analysis();				//picking 2nd block
	dijkstra(G, n, u);
	path = dist_comp(h1, h1);
	traverse(path, face, u);
	fplace();							//placing 2nd block
	right_turn_wls();
	dijkstra(G, n, u);
	path = dist_comp(9, 9);
	traverse(path, face, u);
	proximity_analysis();				//picking 3rd block
	dijkstra(G, n, u);
	path = dist_comp(h2, h2);
	traverse(path, face, u);
	fplace();							//placing 3rd block
	right_turn_wls();
	dijkstra(G, n, u);
	path = dist_comp(29, 29);
	traverse(path, face, u);
	proximity_analysis();				//picking 4th block
	dijkstra(G, n, u);
	path = dist_comp(h1, h1);
	traverse(path, face, u);
	fplace();							//placing 4th block
	right_turn_wls();
	dijkstra(G, n, u);
	path = dist_comp(14, 14);
	traverse(path, face, u);
	proximity_analysis();				//picking 5th block
	dijkstra(G, n, u);
	path = dist_comp(h2, h2);
	traverse(path, face, u);
	fplace();							//placing 5th block
	right_turn_wls();
	dijkstra(G, n, u);
	path = dist_comp(30, 30);
	traverse(path, face, u);
	proximity_analysis();				//picking 6th block
	dijkstra(G, n, u);
	path = dist_comp(h3, h3);
	traverse(path, face, u);
	fplace();							//placing 6th block
	right_turn_wls();
	dijkstra(G, n, u);
	path = dist_comp(3, 3);
	traverse(path, face, u);
	proximity_analysis();				//picking 7th block
	dijkstra(G, n, u);
	path = dist_comp(h5, h5);
	traverse(path, face, u);
	static_reorientation();
	right_turn_inv_wls();
	face = 's';
	forward();
	_delay_ms(130);
	iplace();							//placing 7th block
	back();
	_delay_ms(130);
	left_turn_inv_wls();
	face = 'e';
	dijkstra(G, n, u);
	path = dist_comp(24, 24);
	traverse(path, face, u);
	proximity_analysis();				//picking 8th block
	dijkstra(G, n, u);
	path = dist_comp(h3, h3);
	traverse(path, face, u);
	fplace();							//placing 8th block
	right_turn_wls();
	dijkstra(G, n, u);
	path = dist_comp(25, 25);
	traverse(path, face, u);
	proximity_analysis();				//picking 9th block
	dijkstra(G, n, u);
	path = dist_comp(h5, h5);
	traverse(path, face, u);
	left_turn_inv_wls();
	face = 's';
	forward();
	_delay_ms(130);
	iplace();							//placing 9th block
	back();
	_delay_ms(130);
	right_turn_inv_wls();
	face = 'e';
	dijkstra(G, n, u);
	path = dist_comp(0, 0);
	traverse(path, face, u);
}
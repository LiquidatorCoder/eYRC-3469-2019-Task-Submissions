/*
*
* Team Id: 3469 
* Author List: Abhay Maurya, Ratnesh Mohan Shubhankar Jain, Saumya Gupta 
* Filename: CB_Task_1_Sandbox.cpp 
* Theme: Construct-O-Bot - Specific to eYRC 
* Functions: forward_wls,forward_zigzag,forward_inv,left_turn_wls,right_turn_wls,e_shape,Task_1_1,Task_1_2 
* Global Variables: for_vel,left_vel,right_vel,sleft_vel,sright_vel
*
*/
//You are allowed to define your own function to fulfill the requirement of tasks
//Dont change the name of following functions

#include "CB_Task_1_Sandbox.h"
#include<iostream>						//including iostream header file for console logging
using namespace std;

//global velocity variables
int for_vel = 255;
int left_vel = 80;
int right_vel = 80;
int sleft_vel = 60;
int sright_vel = 60;

/*
*
* Function Name: forward_wls
* Input: node
* Output: void
* Logic: Uses white line sensors to go forward by the number of nodes specified
* Example Call: forward_wls(2); //Goes forward by two nodes
*
*/
void forward_wls(unsigned char node)
{
	unsigned char ls, ms, rs;
	int n = 0;
	while (1)
	{
		ls = ADC_Conversion(1);				//sensor input
		ms = ADC_Conversion(2);
		rs = ADC_Conversion(3);
		if (ls == 255 && ms == 255 && rs == 255)
		{
			n++;
		}
		if (n < node)						//checking if given node is reached
		{
			if (ls == 0 && ms == 255 && rs == 0)					// making choice of movement on the basis of sensor input
			{														//main line following code which helps the robot to move forward along the black line
				forward();
				velocity(for_vel, for_vel);
			}
			else if (ls == 0 && ms == 0 && rs == 255)
			{
				right();
				velocity(right_vel, right_vel);
			}
			else if (ls == 255 && ms == 0 && rs == 0)
			{
				left();
				velocity(left_vel, left_vel);
			}
			else if (ls == 255 && ms == 255 && rs == 0)
			{
				soft_left();
				velocity(0, sleft_vel);
			}
			else if (ls == 0 && ms == 255 && rs == 255)
			{
				soft_right();
				velocity(sright_vel, 0);
			}
			else if (ls == 255 && ms == 0 && rs == 255)
			{
				forward();
				velocity(for_vel, for_vel);
			}
		}
		else													//if node reached then stop
		{
			stop();
			break;
		}
	}
	forward();													//code to move the robot tiny bit so that it is placed on the node
	velocity(255, 255);
	_delay_ms(300);
}

/*
*
* Function Name: forward_zigzag
* Input: node
* Output: void
* Logic: Uses white line sensors to go forward on zigzag lines by the number of nodes specified
* Example Call: forward_zigzag(1); //Goes forward by one node on zigzag
*
*/

void forward_zigzag(unsigned char node)
{
	unsigned char ls, ms, rs;
	int a = 0;
	int n = 0;
	do {															//main do while loop which helps the robot to cross the zigzag part of the track
		ls = ADC_Conversion(1);										//sensor input
		ms = ADC_Conversion(2);
		rs = ADC_Conversion(3);
		
		if (ls == 0 && ms == 0 && rs == 255)						//code which places the robot along the black line so it is parallel to the line
		{
			right();
			velocity(right_vel, right_vel);
		}
		else if (ls == 255 && ms == 0 && rs == 0)
		{
			left();
			velocity(left_vel, left_vel);
		}
		else if (ls == 255 && ms == 255 && rs == 0)
		{
			soft_left();
			velocity(0, sleft_vel);
		}
		else if (ls == 0 && ms == 255 && rs == 255)
		{
			soft_right();
			velocity(sright_vel, 0);
		}
		if (ls == 0 && ms == 255 && rs == 0)
		{
			a = 1;
			cout << "\nRobot is now parallel to the black line.";
		}
	} while (a == 0);
	while (n < node)											//now moving the robot forward along the black line till given node is reached
	{
		forward_wls(1);
		n++;
	}
	
}

/*
*
* Function Name: forward_inv
* Input: void
* Output: void
* Logic: Uses white line sensors to go forward on white and black lines by the number of nodes specified
* Example Call: forward_inv(1); //Goes forward by one node on any line black or white
*
*/


void forward_inv(void)
{
	unsigned char ls, ms, rs;
	int a = 0;														//local variable a which helps in getting feeback from different blocks of this function
	do {															//main do while loop which helps the robot to cross the part of the track where black line inverts to white line
		ls = ADC_Conversion(1);										//sensor input
		ms = ADC_Conversion(2);
		rs = ADC_Conversion(3);
		printf("\n %d %d %d", ls, ms, rs);							//logging sensor values for debugging
		if (ls == 0 && ms == 255 && rs == 0)						//main code block which helps the robot to traverse black line just before the inversion and to also detect the inversion
		{
			forward();
			velocity(60, 60);
		}
		else if (ls == 0 && ms == 0 && rs == 255)					//making choice of movement on the basis of sensor movement
		{
			right();
			velocity(40, 40);
		}
		else if (ls == 255 && ms == 0 && rs == 0)
		{
			left();
			velocity(40, 40);
		}
		else if (ls == 255 && ms == 255 && rs == 0)
		{
			soft_left();
			velocity(0, 20);
		}
		else if (ls == 0 && ms == 255 && rs == 255)
		{
			soft_right();
			velocity(20, 0);
		}
		else if (ls == 255 && ms == 0 && rs == 255)					//if inversion is detected
		{
			a = 2;
			cout << "\nInversion Detected";
			stop();
			break;
		}
	} while (a == 0);												//if inversion is detected this do while loop breaks
	if (a = 2)														//code block which proceeds if inversion is detected
	{
		while (1)													//main while loop
		{								
			ls = ADC_Conversion(1);									//sensor input
			ms = ADC_Conversion(2);
			rs = ADC_Conversion(3);
			printf("\n %d %d %d", ls, ms, rs);						//logging sensor values for debugging
			if (ls == 0 && ms == 255 && rs == 0)					//if black line is again detected just before the node this shows that inversion track is crossed
			{
				a = 3;
				cout << "\nBlack Line Detected.";
				stop();
				break;
			}
			else if (ls == 255 && ms == 255 && rs == 0)				//making choice of movement on the basis of sensor movement which is now totally inverted of the algorithm written in forward_wls
			{
				right();
				velocity(40, 40);
			}
			else if (ls == 0 && ms == 255 && rs == 255)
			{
				left();
				velocity(40, 40);
			}
			else if (ls == 255 && ms == 0 && rs == 255)
			{
				forward();
				velocity(60, 60);

			}
			else if (ls == 255 && ms == 255 && rs == 255)			//else if block which makes the robot to step backwards a liitle bit so that it can sense the white line if all the sensors are off the white line
			{
				back();
				_delay_ms(5);
			}

		}
	}
	if (a == 3)													//code block which proceeds if inversion is ended and black line is again detected
	{
		while (1)												//infinte loop which is breaked only when a node is detected
		{
			ls = ADC_Conversion(1);								//sensor input
			ms = ADC_Conversion(2);
			rs = ADC_Conversion(3);
			printf("\n %d %d %d", ls, ms, rs);
			if (ls == 0 && ms == 255 && rs == 0)				//making choice of movement on the basis of sensor movement
			{
				forward();
				velocity(60, 60);
			}
			else if (ls == 0 && ms == 0 && rs == 255)
			{
				right();
				velocity(40, 40);
			}
			else if (ls == 255 && ms == 0 && rs == 0)
			{
				left();
				velocity(40, 40);
			}
			else if (ls == 255 && ms == 255 && rs == 0)
			{
				soft_left();
				velocity(0, 20);
			}
			else if (ls == 0 && ms == 255 && rs == 255)
			{
				soft_right();
				velocity(20, 0);
			}
			else if (ls == 255 && ms == 255 && rs == 255)		//else block which helps in detecting node
			{
				a = 4;
				cout<<"\nNode Detected.";
				stop();
				break;
			}

		}
	}
	if (a == 4)													//code block which proceeds if node is detected
	{
		forward();												//code to move the robot tiny bit so that it is placed on the node
		velocity(255, 255);
		_delay_ms(300);
	}
}

/*
*
* Function Name: left_turn_wls
* Input: void
* Output: void
* Logic: Uses white line sensors to turn left until black line is encountered
* Example Call: left_turn_wls(); //Turns right until black line is encountered
*
*/
void left_turn_wls(void)
{
	left();												//code which helps the robot to ignore the black line which is going straight so that it can focus on line which is going to the left
	_delay_ms(250);
	while (ADC_Conversion(2) != 255)					//while loop which detects black line using middle sensor so that the robot stops turning
	{
		left();
		velocity(127, 127);
		_delay_ms(2);
	}
}

/*
*
* Function Name: right_turn_wls
* Input: void
* Output: void
* Logic: Uses white line sensors to turn right until black line is encountered
* Example Call: right_turn_wls(); //Turns right until black line is encountered
*/
void right_turn_wls(void)
{
	right();											//code which helps the robot to ignore the black line which is going straight so that it can focus on line which is going to the right
	_delay_ms(250);
	while (ADC_Conversion(2) != 255)					//while loop which detects black line using middle sensor so that the robot stops turning
	{
		right();
		velocity(127, 127);
		_delay_ms(2);
	}
}

/*
*
* Function Name: e_shape
* Input: void
* Output: void
* Logic: Use this function to make the robot trace a e shape path on the arena
* Example Call: e_shape();
*/
void e_shape(void)
{
	forward_wls(1);										//calling forward_wls and right_turn_wls to complete the e-shape
	right_turn_wls();
	forward_wls(1);
	forward_wls(1);
	right_turn_wls();
	forward_wls(1);
	right_turn_wls();
	forward_wls(1);
	right_turn_wls();
	forward_wls(1);
}


/*
*
* Function Name: Task_1_1
* Input: void
* Output: void
* Logic: Use this function to encapsulate your Task 1.1 logic
* Example Call: Task_1_1();
*/
void Task_1_1(void)
{
	forward_wls(1);									//calling forward_wls, left_turn_wls and right_turn_wls to complete the task1.1
	cout << "\nForward 1 Node";
	right_turn_wls();
	cout << "\n1 Right Node";
	forward_wls(1);
	cout << "\nForward 2 Node";
	forward_wls(1);
	cout << "\nForward 3 Node";
	forward_wls(1);
	cout << "\nForward 4 Node";
	forward_wls(1);
	cout << "\nForward 5 Node";
	left_turn_wls();
	cout << "\n5 Left Node";
	forward_wls(1);
	cout << "\nForward 6 Node";
	left_turn_wls();
	cout << "\n6 Left Node";
	forward_wls(1);
	cout << "\nForward 7 Node";
	right_turn_wls();
	cout << "\n7 Right Node";
	forward_wls(1);
	cout << "\nForward 8 Node";
	left_turn_wls();
	cout << "\n8 Left Node";
	forward_wls(1);
	cout << "\nForward 9 Node";
	right_turn_wls();
	cout << "\n9 Right Node";
	forward_zigzag(1);								//calling forward_zigzag when needed
	cout << "\nForward 10 Node";
	left_turn_wls();
	cout << "\n10 Left Node";
	forward_wls(1);
	cout << "\nForward 11 Node";
	right_turn_wls();
	cout << "\n11 Right Node";
	forward_wls(1);
	cout << "\nForward 12 Node";
	left_turn_wls();
	cout << "\n12 Left Node";
	forward_wls(1);
	cout << "\nForward 13 Node";
	right_turn_wls();
	cout << "\n13 Right Node";
	forward_inv();									//calling forward_inv when needed
	cout << "\nForward 14 Node";
	right_turn_wls();
	cout << "\n14 Right Node";
	forward_wls(1);
	cout << "\nForward 15 Node";
	left_turn_wls();
	cout << "\n15 Left Node";
	forward_wls(1);
	cout << "\nForward till Goal!";
	//Goal is Reached!

}

/*
*
* Function Name: Task_1_2
* Input: void
* Output: void
* Logic: Use this function to encapsulate your Task 1.2 logic
* Example Call: Task_1_2();
*/
void Task_1_2(void)
{
	//write your task 1.2 logic here
}